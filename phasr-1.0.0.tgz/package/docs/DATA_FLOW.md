# PHASR Data Flow & Relationships

This document visualizes the exact physical lifecycle of payload processing within the PHASR ecosystem, mapping how data transitions from the Command-Line Wrapper down into the Windows Kernel (MFT) and Linux Kernel (getdents64).

## 1. Cross-Platform Execution Sequence Flow
The following sequence diagram traces the chronological execution path of a codebase scan. Notice how the NodeJS CLI dynamically routes execution to the natively compiled OS-specific binary, entirely detaching itself from the hot path.

```mermaid
sequenceDiagram
    autonumber
    actor User
    participant CLI as Node.js Universal Router
    participant Main as C++ Main Thread (Orchestrator)
    participant Buffer as SPMC Lock-Free Ring Buffer
    participant Worker as C++ Hardware Threads (x256)
    participant Kernel as Win32 (MFT) / POSIX (getdents64)

    User->>CLI: `phasr . --threads 64`
    CLI->>CLI: Detect OS & Architecture (win32, arm64, linux)
    CLI->>Main: Execute Native Binary (`engine.exe` or `phasr_arm64`)
    
    rect rgb(20, 40, 20)
        Note over Main, Kernel: KERNEL-BYPASS ZERO-ALLOCATION HOT LOOP
        Main->>Kernel: Request Physical Disk Sectors (FSCTL_ENUM_USN_DATA / getdents64)
        Kernel-->>Main: Raw Directory/File Handlers
        Main->>Buffer: Store Path in `fileQueue[head]`
        Main->>Buffer: std::atomic `head++` (Release Semantics)
        
        Buffer-->>Worker: Spinlock acquires `tail` (Compare-And-Swap)
        Worker->>Kernel: Open / CreateFileA (File Path)
        Worker->>Kernel: ReadFile / read (up to 30MB chunk)
        Kernel-->>Worker: Physical Bytes mapped to 30MB VirtualAlloc/mmap Memory
        
        par 8-Module Wave Collapse
            Worker->>Worker: M3 (Entropy): Calculate Shannon H(X) via ASM
            Worker->>Worker: M4 (Taint): Scan std::string_view for injections
            Worker->>Worker: M5 (Temporal): clock_gettime / GetTickCount drift detection
            Worker->>Worker: M6 (Dissection): Unroll Opcodes to find NOP Sleds
        end
        
        alt Module Triggered Anomaly
            Worker->>Main: lock(printCS) -> push_back(anomalies)
        end
    end
    
    Main->>Main: M7 (Tradeoff): Compute Liability vs Physical Mass ($50,000 threshold)
    Main->>User: Generate Wave Collapse Output & `phasr_security_report.md`
```

---

## 2. Entity-Relationship (Memory Physics) Diagram
At extreme throughput speeds (200,000+ f/s), typical object-oriented structures trigger catastrophic heap fragmentation and thread contention. PHASR models its memory entirely as statically sized contiguous memory blocks mapped to CPU Cache lines, utilizing zero-allocation `std::string_view` structures.

The following ER diagram maps the physical relationships of the memory structures across OS targets:

```mermaid
erDiagram
    UNIVERSAL_ROUTER ||--o{ OS_NATIVE_ENGINE : spawns_via_stdio_inherit
    OS_NATIVE_ENGINE ||--|| SPMC_RING_BUFFER : manages
    OS_NATIVE_ENGINE ||--o{ WORKER_THREAD : spawns_up_to_256
    
    SPMC_RING_BUFFER {
        struct LinuxFileTask[8192] "Contiguous Array Queue"
        std_atomic_int head "Producer Index (Main Thread)"
        std_atomic_int tail "Consumer Index (CAS Target)"
    }
    
    WORKER_THREAD ||--|| THREAD_MEMORY_BUFFER : reserves
    THREAD_MEMORY_BUFFER {
        size_t MAX_BUFFER_SIZE "Strict 30MB Cap per Thread"
        string Allocation "VirtualAlloc (Win32) / mmap (POSIX)"
        std_string_view content "Zero-Allocation Heap Bypass"
    }
    
    WORKER_THREAD ||--|| FREQUENCY_ARRAY : computes
    FREQUENCY_ARRAY {
        uint32_t counts[256] "Byte Frequency Histogram (ARM64 ABI)"
        double H_X "Shannon Entropy Float"
    }

    WORKER_THREAD }o--|| PIPELINE_ANOMALIES : triggers
    PIPELINE_ANOMALIES {
        vector m3_anomalies "Critical Section Protected"
        vector m4_anomalies "Critical Section Protected"
        vector m5_anomalies "Critical Section Protected"
        vector m6_anomalies "Critical Section Protected"
    }
```
